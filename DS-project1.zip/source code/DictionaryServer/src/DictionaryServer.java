import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class DictionaryServer {

	private int num = 0;
	private ServerSocket listeningSocket = null;
	
	public DictionaryServer(OnlineDictionary dictionary,int port){
		try {
			listeningSocket = new ServerSocket(port);
			while(true){
				System.out.println("Server is listening for connection");
				Socket clientSocket = listeningSocket.accept();
				num++;
				System.out.println("Client: "+ num +" is connected");
				MyThread thread = new MyThread(clientSocket,dictionary,this);
				thread.start();
			}
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			if (listeningSocket != null){
				try {
					listeningSocket.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}
	
	public static void main(String[] args) {
		try{
			String portNumber = args[0];
			String file = args[1];
			OnlineDictionary dictionary = new OnlineDictionary();
			dictionary.readData(file);
			new DictionaryServer(dictionary,Integer.parseInt(portNumber));
		}
		catch(NumberFormatException e){
			System.out.println("Please enter valid port number");
		}
		
		
	}

}
