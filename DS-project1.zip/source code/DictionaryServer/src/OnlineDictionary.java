import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Hashtable;

public class OnlineDictionary {
	
	private Hashtable<String,String> dictionary = new Hashtable<String, String>();
	
	public OnlineDictionary (){
//		dictionary.put("avocado","a tropical fruit with thick, green, or purple skin, a large, round seed, and green flesh that can be eaten" );
//		dictionary.put("life", "the period between birth and death, or the experience or state of being alive");
//		dictionary.put("happiness", "the feeling of being happy");
//		dictionary.put("hello", "used when meeting or greeting someone");
//		dictionary.put("crystal", "a transparent glass or plastic cover for a watch or clock");
//		dictionary.put("apple", "a round fruit with firm, white flesh and a green, red, or yellow skin");
//		dictionary.put("aurora", "The dawn in the early morning");
//		dictionary.put("unicorn", "an imaginary white creature like a horse with a single horn growing from the front of its head");	
	}
	
	public synchronized boolean addWords(String world,String meaning){
		if (dictionary.get(world)==null){
			dictionary.put(world, meaning);
			return true;
		}else{
			return false;
		}
		
	}
	
	public synchronized boolean deleteWords(String world){
		if (dictionary.get(world)==null){
			return false;
		}else {
			dictionary.remove(world);
			return true;
		}
		
	}
	
	public synchronized String searchWords(String world){
		if (dictionary.get(world)!=null){
			return dictionary.get(world);
		}else{
			return "not found";
		}
		
	}
	
    public void writeData(){
    	try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("dictionary.dat"));
			out.writeObject(dictionary);
			out.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
    	
		
	}
	
	
	public void readData(String dictionaryfile){
		File fileObject = new File(dictionaryfile);
		if (fileObject.exists()){
			ObjectInputStream in;
			try {
				in = new ObjectInputStream(new FileInputStream(fileObject));
				dictionary = (Hashtable<String, String>) in.readObject();
				in.close();
			}
			catch (ClassNotFoundException e) {
				System.out.println("Problem with file input");
			} catch (IOException e) {
				System.out.println(e.getMessage());
				System.exit(0);
			}
			
		}
	}
	
	
}
