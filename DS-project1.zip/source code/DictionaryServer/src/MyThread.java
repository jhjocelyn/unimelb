import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.ArrayList;

public class MyThread extends Thread{
	
	private Socket clientSocket;
	private OnlineDictionary dictionary;
	private BufferedReader in;
	private BufferedWriter out;
	private String clientInput = null;
	private String msg = null;
	
	public MyThread(Socket clientSocket,OnlineDictionary dictionary,DictionaryServer server){
		this.clientSocket = clientSocket;
		this.dictionary = dictionary;
		
	}
	
	private ArrayList<String> getCommand(String input){
		ArrayList<String> command = new ArrayList<String>();
		for(String str : input.split("-")){
			command.add(str);
		}
		return command;
	}

	public void close(){
		try {
			in.close();
			out.close();
			clientSocket.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public void run(){
		//input and output 
		try {
			in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(),"UTF-8"));
			out  = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream(),"UTF-8"));
			//read the msg sent by the client
	
			while((clientInput = in.readLine())!=null){
				System.out.println(clientInput);
				ArrayList<String> command = getCommand(clientInput);
				switch(command.get(0)) {
					case "search": msg = dictionary.searchWords(command.get(1));
								   out.write("search-" + msg +"\n" );
								   out.flush();
								   break;
					case "add":    boolean feedback = dictionary.addWords(command.get(1), command.get(2));
								   if(feedback ==true){
									   msg = command.get(1)+" is added to the dictionary";
									   out.write("add-" + msg +"\n");
									   out.flush();
								   }else{
									   msg = command.get(1)+" has already existed";
									   out.write("error-"+msg+"\n");
									   out.flush();
								   }
								   break;
					case "delete": boolean feedback2 = dictionary.deleteWords(command.get(1));
								   if (feedback2){
									   msg = command.get(1)+" is deleted from the dictionary";
									   out.write("delete-"+msg+"\n");
									   out.flush();
								   }else{
									   msg = command.get(1)+" has not found!";
									   out.write("delete-"+msg+"\n");
									   out.flush();
								   }
								   break;
								  
					default:       msg = "Command not found";
								   out.write("error-"+msg+"\n");
								   out.flush();
								   break;
				}
				dictionary.writeData();
			}
			
			System.out.println("this socket is closed");
			close();
			
		} catch (UnsupportedEncodingException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
