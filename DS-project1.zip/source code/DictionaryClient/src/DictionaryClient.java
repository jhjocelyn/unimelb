import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import java.awt.TextArea;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JEditorPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class DictionaryClient{
	
	public static Boolean isExit = false;
	private JFrame frame;
	private JTextField searchField;
	private JTextField addField;
	private JTextField deleteField;
	private static JTextField serverMsg;
	private static TextArea searchArea;

	private static Socket socket;
	private static BufferedWriter out;
	private static BufferedReader in;
	private Scanner sc;
	private JTextArea meaningField;

	
	//Launch the application.
	public static void main(String[] args) {
		String ip=null;
		int port=0;
		try{
			ip = args[0];
			port = Integer.parseInt(args[1]);
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					DictionaryClient window = new DictionaryClient();
					window.frame.setVisible(true);
				}
			});
			connectToServer(ip,port);
		}catch (NumberFormatException e){
			System.out.println("Please enter the right format of arguments");
		}catch(Exception e){
			System.out.println(e.getMessage());
			
		}
		
	}
	
	public DictionaryClient(){
		initialize();
	}
	


	//Initialise the GUI
		private void initialize() {
			frame = new JFrame();
			frame.getContentPane().setBackground(new Color(153, 204, 153));
			frame.setTitle("Online Dictionary");
			frame.setSize(650,400);
			frame.setLocationRelativeTo(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);

			
			serverMsg = new JTextField();
			serverMsg.setHorizontalAlignment(SwingConstants.CENTER);
			serverMsg.setForeground(new Color(255, 102, 102));
			serverMsg.setFont(new Font("Chalkboard", Font.BOLD, 13));
			serverMsg.setText("Welcome to Online Dictionary");
			serverMsg.setBounds(152, 27, 321, 35);
			frame.getContentPane().add(serverMsg);
			serverMsg.setColumns(10);

			JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);

			tabbedPane.setBounds(51, 74, 549, 298);
			frame.getContentPane().add(tabbedPane);

			JPanel search = new JPanel();
			tabbedPane.addTab("Search",new ImageIcon(DictionaryClient.class.getResource("/isearch.png")), search, null);
			search.setLayout(null);


			searchArea = new TextArea();
			searchArea.setBounds(202, 30, 293, 179);
			search.add(searchArea);

			searchField = new JTextField();

			searchField.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						String msgout = "";
						msgout = searchField.getText();
						try {
							out.write("search-" + msgout +"\n");
							out.flush();
						} catch (SocketException e2){
							System.out.println("Server Shutdown");
							serverMsg.setText("Server Shutdown");
						}catch (IOException e1) {
							System.out.println(e1.getMessage());
						}catch(NullPointerException e3){
							serverMsg.setText("disconntected, wrong port id");
						}
					}
			});

			searchField.setBounds(27, 30, 137, 33);
			search.add(searchField);
			searchField.setColumns(10);

			JPanel add = new JPanel();
			tabbedPane.addTab("Add", new ImageIcon(DictionaryClient.class.getResource("/iadd.png")), add, null);

			JPanel delete = new JPanel();
			tabbedPane.addTab("Delete",new ImageIcon(DictionaryClient.class.getResource("/idelete.png")),delete, null);
			delete.setLayout(null);

			deleteField = new JTextField();
			deleteField.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						String msgout ="";
						msgout = deleteField.getText();
						try {
							out.write("delete-"+msgout+"\n");
							out.flush();
						}catch (SocketException e2){
							System.out.println("Server Shutdown");
							serverMsg.setText("Server Shutdown");
						} 
						catch (IOException e1) {
							System.out.println(e1.getMessage());
						}catch(NullPointerException e3){
							serverMsg.setText("disconntected, wrong port id");
						}
				}
			});
		

			deleteField.setColumns(10);
			deleteField.setBounds(195, 50, 137, 33);
			delete.add(deleteField);
			add.setLayout(null);
			add.setLayout(null);

			addField = new JTextField();
			addField.setForeground(new Color(204, 204, 204));
			addField.setText("world to add");
			
			
		
			addField.setColumns(10);
			addField.setBounds(47, 35, 209, 33);
			add.add(addField);
			
			meaningField = new JTextArea();
			meaningField.setLineWrap(true);
			meaningField.setBounds(87, 92, 321, 130);
			add.add(meaningField);
			
			JButton addConfirmBtn = new JButton("Confirm");
			addConfirmBtn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						String msgout = "";
						if (!(meaningField.getText().equals(""))){
							msgout = addField.getText() +"-"+ meaningField.getText();
							try {
								out.write("add-"+ msgout+ "\n");
								out.flush();
							}catch (SocketException e2){
								System.out.println("Server Shutdown");
								serverMsg.setText("Server Shutdown");
							} 
							catch (IOException e1) {
								System.out.println(e1.getMessage());
							}catch(NullPointerException e3){
								serverMsg.setText("disconntected, wrong port id");
							}
						}else{
							serverMsg.setText("meaning field is empty!!!");
						}
							
				}
			});
			addConfirmBtn.setBounds(313, 38, 117, 29);
			add.add(addConfirmBtn);
			
			
			
			
			JLabel iconD = new JLabel("");
			iconD.setIcon(new ImageIcon(DictionaryClient.class.getResource("/idictionary.png")));
			iconD.setBounds(103, 30, 32, 32);
			frame.getContentPane().add(iconD);
			
			
		}
		

	
		
	//Parse the reply from the server
	private static ArrayList<String> getReply(String input){
		ArrayList<String> reply = new ArrayList<String>();
		for(String str : input.split("-")){
			reply.add(str);
		}
		return reply;
	}
	
	
	//connect to Server and  communicate to server
	public static void connectToServer(String ip,int port){
		try{
			socket = new Socket(ip,port);
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),"UTF-8"));
			in = new BufferedReader(new InputStreamReader(socket.getInputStream(),"UTF-8"));
			
			while(!isExit){
				String msgin ="";
				while ((msgin = in.readLine())!=null){
						ArrayList<String> response = getReply(msgin);
						switch(response.get(0)){
						case "search": searchArea.setText(response.get(1));
						break;
						case "add" :   serverMsg.setText(response.get(1));
						break;
						case "delete": serverMsg.setText(response.get(1));
						break;
						case "error": serverMsg.setText(response.get(1));
						break;
						default : serverMsg.setText("Error");
						break;
					}
				}
			}
		}catch(UnknownHostException e){
			System.out.println(e.getMessage());
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
		}finally{
			if (socket!=null){
				try {
					socket.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
			}
		} 

	}

	//close inputStream,outputStream
	public void close(){
		sc.close();
		try {
			in.close();
			out.close();
		} catch (IOException e){
			System.out.println(e.getMessage());
		}

	}
}
